laravel-library
==========================

[![Build Status](https://travis-ci.org/intrip/laravel-library.png)](https://travis-ci.org/intrip/laravel-library)

Laravel general library package

#Attention
###This package does not contain any documentation, is intented for internal use only