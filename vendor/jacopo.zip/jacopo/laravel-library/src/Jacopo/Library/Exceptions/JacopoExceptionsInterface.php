<?php namespace Jacopo\Library\Exceptions;
/**
 * Interface JacopoExceptionsInterface
 *
 * To catch multiple exceptions
 *
 * @package Exceptions
 */
interface JacopoExceptionsInterface {}