<?php namespace Jacopo\Library\Exceptions;

class ValidationException extends \Exception implements JacopoExceptionsInterface {}