<?php namespace Jacopo\Library\Exceptions;

class NotFoundException extends \Exception implements JacopoExceptionsInterface {}