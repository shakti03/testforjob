<?php namespace Jacopo\Library\Exceptions;

class MailException extends \Exception implements JacopoExceptionsInterface {}