<?php namespace Jacopo\Library\Exceptions;

class InvalidException extends \Exception implements JacopoExceptionsInterface {}