#Changelog:

###version 1.1.3
- Enhanced postgres support
- Better menu permission handling
- Minor bugfixes

###version 1.1.4
- Minor bugfixes

###version 1.1.5
- Minor bugfixes

###version 1.1.6
- Auto logout of a banned user if is already logged in
- Self password edit for every user
- Gravatar support

###version 1.1.7
- has_perm filter to handle custom permission to a given route

###version 1.1.8
- fixed bug in the profile page of the default admin user

###version 1.1.9
- Multiple ordering search filter
- Better fit and gravatar handling
- Basic events to hook into the application

###version 1.1.10
- Fixed some javascript paths
- Updated to Jquery 1.1.11
- Fixed a bug that was saving multiple profiles when saving the user page

###version 1.1.11
- Fixed base64 avatar encoding bug

###version 1.1.13
- Fixed some documentation information about system requirements

###version 1.1.14
- Fixed some hardcoded messages from italian to english

###version 1.1.15
- Fixed a group edit error page bug

###version 1.2.1-6
- Ajax captcha
- Added editable routes in configuration file
- Extended test coverage
- Setted up basic acceptance testsuite