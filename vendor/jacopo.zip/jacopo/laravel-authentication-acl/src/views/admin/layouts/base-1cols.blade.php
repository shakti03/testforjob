@extends('laravel-authentication-acl::admin.layouts.base')

@section('container')
    <div class="col-mg-12">
        @yield('content')
    </div>
@stop