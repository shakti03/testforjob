<?php
require __DIR__ . '/composers/menu.php';

require __DIR__ . '/composers/select_items.php';

require __DIR__ . '/composers/dashboard.php';

require __DIR__ . '/composers/permissions.php';

require __DIR__ . '/composers/others.php';
