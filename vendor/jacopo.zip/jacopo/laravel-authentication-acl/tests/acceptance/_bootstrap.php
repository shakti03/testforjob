<?php
$testEnvironment = 'testing-acceptance';
require __DIR__ . "/../helpers/laravel_bootstrap.php";

_codeCeption_setUp($testEnvironment);
